package com.jaren.likeview.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.jaren.likeview.R;

/**
 * Created
 * by jaren on 2017/5/23.
 */

public class LikeView extends View {
    /**
     * 圆最大半径
     */
    private float mRadius;
    /**
     * View变化用时
     */
    private int mCycleTime;
    /**
     * Bézier曲线画圆的近似常数
     */
    private static final float c = 0.551915024494f;
    private static final int HEART_VIEW = 0;
    private static final int CIRCLE_VIEW = 1;
    private static final int RING_VIEW = 2;
    private static final int RING_POINT__HEART_VIEW = 3;

    private float mCenterX;
    private float mCenterY;
    private Paint mPaint;
    private float mOffset;
    private OnClickListener mListener;
    private ValueAnimator animatorTime;
    private ValueAnimator animatorArgb;
    private int mCurrentRadius;
    private int mCurrentColor;
    private int mCurrentState;
    private float mCurrentPercent;

    private PointF tPointA;
    private PointF tPointB;
    private PointF tPointC;
    private PointF rPointA;
    private PointF rPointB;
    private PointF rPointC;
    private PointF bPointA;
    private PointF bPointB;
    private PointF bPointC;
    private PointF lPointA;
    private PointF lPointB;
    private PointF lPointC;


    public LikeView(Context context) {
        this(context, null);
    }

    public LikeView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LikeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        TypedArray array = context.getTheme().obtainStyledAttributes(attrs, R.styleable.LikeView, defStyleAttr, 0);
        mRadius = array.getDimension(R.styleable.LikeView_cirRadius, dp2px(140));
        mCycleTime = array.getInt(R.styleable.LikeView_cycleTime, 6000);
        mOffset = c * mRadius;
        mCenterX = mRadius;
        mCenterY = mRadius;
        mPaint = new Paint();
        mCurrentRadius = (int) mRadius;
        mCurrentColor = 0Xff657487;

    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.translate(mCenterX, mCenterY);//使坐标原点在canvas中心位置

        switch (mCurrentState) {
            case HEART_VIEW:
                drawHeart(canvas, mCurrentRadius, mCurrentColor);
                break;
            case CIRCLE_VIEW:
                drawCircle(canvas, mCurrentRadius, mCurrentColor);
                break;
            case RING_VIEW:
                drawRing(canvas, mCurrentRadius, mCurrentColor);
                break;
        }
    }


    //绘制心形
    private void drawHeart(Canvas canvas, int radius, int color) {
        initControlPoints(radius);
        mPaint.setColor(color);
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL);
        Path path = new Path();
        path.moveTo(tPointB.x, tPointB.y);
        path.cubicTo(tPointC.x, tPointC.y, rPointA.x, rPointA.y, rPointB.x, rPointB.y);
        path.cubicTo(rPointC.x, rPointC.y, bPointC.x, bPointC.y, bPointB.x, bPointB.y);
        path.cubicTo(bPointA.x, bPointA.y, lPointC.x, lPointC.y, lPointB.x, lPointB.y);
        path.cubicTo(lPointA.x, lPointA.y, tPointA.x, tPointA.y, tPointB.x, tPointB.y);
        canvas.drawPath(path, mPaint);
    }

    //绘制圆
    private void drawCircle(Canvas canvas, int radius, int color) {

        mPaint.setColor(color);
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setStrokeWidth(3f);
        canvas.drawCircle(0f, 0f, radius, mPaint);
        Log.i("LikeViewtag", mCurrentColor + "drawCircle" + mCurrentRadius + "drawCircle");

    }

    //绘制圆环
    private void drawRing(Canvas canvas, int radius, int color) {

        mPaint.setColor(color);
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.STROKE);
//        mPaint.setStrokeWidth(2f);
//        canvas.drawCircle(0f, 0f, radius * (mCurrentPercent - 0.3f), mPaint);
//        mPaint.setStyle(Paint.Style.FILL);
//        canvas.drawCircle(0f, 0f, radius, mPaint);
        float  percent = 1f - mCurrentPercent+0.2f>1f?1f:1f - mCurrentPercent+0.2f;
        mPaint.setStrokeWidth(mRadius*percent);
        RectF rectF = new RectF(-radius/2, -radius/2, radius/2, radius/2);
        canvas.drawArc(rectF, 0, 360, false, mPaint);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mCenterX = w / 2;
        mCenterY = h / 2;

    }

    /**
     * 初始化Bézier 曲线四组控制点
     */
    private void initControlPoints(int mRadius) {
        mOffset = c * mRadius;

        tPointA = new PointF(-mOffset, -mRadius);
        tPointB = new PointF(0, -mRadius * 0.5f);
        tPointC = new PointF(mOffset, -mRadius);

        rPointA = new PointF(mRadius, -mOffset);
        rPointB = new PointF(mRadius, 0);
        rPointC = new PointF(mRadius * 0.9f, mOffset);

        bPointA = new PointF(-mOffset, mRadius * 0.7f);
        bPointB = new PointF(0, mRadius);
        bPointC = new PointF(mOffset, mRadius * 0.7f);

        lPointA = new PointF(-mRadius, -mOffset);
        lPointB = new PointF(-mRadius, 0);
        lPointC = new PointF(-mRadius * 0.9f, mOffset);
    }


    /**
     * 展现View点击后的变化效果
     */
    private void startViewMotion() {
        if (animatorTime != null && animatorTime.isRunning())
            return;
        animatorTime = ValueAnimator.ofInt(0, 120);//100?
        animatorTime.setDuration(mCycleTime);
        animatorTime.setInterpolator(new LinearInterpolator());//需要随时间匀速变化
        animatorTime.start();
        animatorTime.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int animatedValue = (int) animation.getAnimatedValue();
                Log.i("LikeViewtag", animatedValue + "");

                if (animatedValue == 0) {
                    if (animatorArgb == null || !animatorArgb.isRunning()) {
                        animatorArgb = ofArgb(0Xff657487, 0Xfff74769, 0Xffde7bcc);//100?
                        animatorArgb.setDuration(mCycleTime * 28 / 120);
                        animatorArgb.setInterpolator(new LinearInterpolator());
                        animatorArgb.start();
                    }
                } else if (animatedValue <= 20) {
                    float percent = calcPercent(0f, 20f, animatedValue);
                    mCurrentRadius = (int) (mRadius - mRadius * percent);
                    if (animatorArgb != null && animatorArgb.isRunning())
                        mCurrentColor = (int) animatorArgb.getAnimatedValue();
                    Log.i("LikeViewtag", mCurrentColor + "mCurrentColor" + mCurrentRadius + "mCurrentRadius|||"+percent+"percent");
                    mCurrentState = HEART_VIEW;
                    invalidate();

                } else if (animatedValue <= 28) {
                    float percent = calcPercent(20f, 34f, animatedValue);//此阶段未达到最大半径
                    mCurrentRadius = (int) (2*mRadius * percent);
                    if (animatorArgb != null && animatorArgb.isRunning())
                        mCurrentColor = (int) animatorArgb.getAnimatedValue();
                    Log.i("LikeViewtag", mCurrentColor + "mCurrentColor" + mCurrentRadius + "mCurrentRadius|||"+percent+"percent");
                    mCurrentState = CIRCLE_VIEW;
                    invalidate();
                } else if (animatedValue <= 34) {
                    float percent = calcPercent(20f, 34f, animatedValue);//半径接上一阶段增加
                    mCurrentPercent = percent;
                    mCurrentRadius = (int) (2*mRadius * percent);
                    if (animatorArgb != null && animatorArgb.isRunning())
                        mCurrentColor = (int) animatorArgb.getAnimatedValue();
                    Log.i("LikeViewtag", mCurrentColor + "mCurrentColor" + mCurrentRadius + "mCurrentRadius|||"+percent+"percent");
                    mCurrentState = RING_VIEW;
                    invalidate();
                }
                if (animatedValue == 120) {
                    Log.i("LikeViewtag", "end");
                    animatorTime.cancel();
                    animatorTime.removeAllListeners();
                }

            }
        });


    }

    private float calcPercent(float start, float end, float current) {
        return (current - start) / (end - start);
    }


    /**
     * @param values
     * @return 由于颜色变化的动画API是SDK21 添加的，这里导入了源码的 ArgbEvaluator
     */
    private ValueAnimator ofArgb(int... values) {
        ValueAnimator anim = new ValueAnimator();
        anim.setIntValues(values);
        anim.setEvaluator(ArgbEvaluator.getInstance());
        return anim;
    }

    private float dp2px(int value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    @Override
    public void setOnClickListener(@Nullable OnClickListener l) {
        mListener = l;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int x = (int) event.getRawX();
        int y = (int) event.getRawY();
        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
                if (x + getLeft() < getRight() && y + getTop() < getBottom()) {//点击在View区域内
                    Log.i("LikeViewtag", "点击在View区域内");

                    startViewMotion();
                    mListener.onClick(this);
                }
                break;
        }
        return true;
    }


}
